local addonName, ns = ...

-- 1. DEFINE ITEMS TO TRACK
-- [ItemID] = "Name"
local reagents = {
    [17032] = { name = "Rune of Portals",       abbr = "P" },
    [17031] = { name = "Rune of Teleportation", abbr = "T" },
    [17020] = { name = "Arcane Powder",         abbr = "AP" },
}

-- Order to display in the tooltip
local displayOrder = { 17032, 17031, 17020 }

-- 2. GET LIBDATABROKER
local ldb = LibStub and LibStub("LibDataBroker-1.1", true)
if not ldb then
    -- Fallback if LDB isn't present (rare, but good practice)
    print(addonName .. ": LibDataBroker not found. Please install a broker display addon.")
    return
end

-- 3. CREATE DATA OBJECT
local dataObj = ldb:NewDataObject("MageReagents", {
    type = "data source",
    text = "Reagents Loading...",
    icon = "Interface\\Icons\\Spell_Arcane_TeleportIronforge", -- Mage-themed icon
    OnTooltipShow = function(tooltip)
        tooltip:AddLine("Mage Reagents")
        tooltip:AddLine(" ") -- Spacer

        for _, id in ipairs(displayOrder) do
            local count = GetItemCount(id, false, false) -- Count items in bags
            local r, g, b = 1, 1, 1

            -- Color red if count is 0, yellow if low (< 5), green otherwise
            if count == 0 then
                r, g, b = 1, 0.2, 0.2
            elseif count < 5 then
                r, g, b = 1, 1, 0.2
            end

            tooltip:AddDoubleLine(reagents[id].name, count, 1, 1, 1, r, g, b)
        end
    end,
})

-- 4. UPDATE FUNCTION
local function UpdateReagentCounts()
    local textParts = {}

    for _, id in ipairs(displayOrder) do
        local count = GetItemCount(id, false, false)
        local abbr = reagents[id].abbr

        -- Formatting: "P: 5"
        -- We apply color codes directly to the string for the Bar display
        local color = "ffffff" -- Default White
        if count < 5 then color = "ff0000" end -- Red if low

        table.insert(textParts, string.format("|cff%s%s: %d|r", color, abbr, count))
    end

    -- Update the text on the bar (e.g., "P: 12 T: 5 AP: 40")
    dataObj.text = table.concat(textParts, "  ")
end

-- 5. EVENT HANDLING
local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("BAG_UPDATE")

frame:SetScript("OnEvent", function(self, event, ...)
    UpdateReagentCounts()
end)
