local addonName, ns = ...

-- 1. CONFIGURATION
local reagents = {
    [17032] = { name = "Rune of Portals",       abbr = "P" },
    [17031] = { name = "Rune of Teleportation", abbr = "T" },
    [17020] = { name = "Arcane Powder",         abbr = "AP" },
}
local displayOrder = { 17032, 17031, 17020 }

-- 2. CREATE THE STANDALONE FRAME
-- We use "BackdropTemplate" which is required in TBC/WotLK Classic
local f = CreateFrame("Frame", "MageReagentsFrame", UIParent, "BackdropTemplate")
f:SetSize(100, 24) -- Initial size, will auto-adjust
f:SetPoint("CENTER")
f:SetMovable(true)
f:EnableMouse(true)
f:RegisterForDrag("LeftButton")
f:SetClampedToScreen(true)

-- Visuals (Black semi-transparent background)
f:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
f:SetBackdropColor(0, 0, 0, 0.8)

-- Text Label
f.text = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
f.text:SetPoint("CENTER", 0, 0)
f.text:SetTextColor(1, 1, 1)

-- 3. BROKER SUPPORT (LDB)
local ldb = LibStub and LibStub("LibDataBroker-1.1", true)
local dataObj
if ldb then
    dataObj = ldb:NewDataObject("MageReagents", {
        type = "data source",
        text = "Loading...",
        icon = "Interface\\Icons\\Spell_Arcane_TeleportIronforge",
    })
    end

    -- 4. SHARED TOOLTIP FUNCTION (Used by both Frame and Broker)
    local function ShowTooltip(anchor)
    GameTooltip:SetOwner(anchor, "ANCHOR_TOP")
    GameTooltip:AddLine("Mage Reagents")
    GameTooltip:AddLine(" ")

    for _, id in ipairs(displayOrder) do
        local count = GetItemCount(id, false, false)
        local r, g, b = 1, 1, 1
        if count == 0 then r,g,b = 1,0.2,0.2 elseif count < 5 then r,g,b = 1,1,0.2 end
            GameTooltip:AddDoubleLine(reagents[id].name, count, 1, 1, 1, r, g, b)
            end

            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("<Shift-Drag to move window>", 0.6, 0.6, 0.6)
            GameTooltip:Show()
            end

            -- 5. MOUSE INTERACTION FOR STANDALONE WINDOW
            f:SetScript("OnEnter", function(self) ShowTooltip(self) end)
            f:SetScript("OnLeave", function() GameTooltip:Hide() end)

            -- Dragging Logic (Requires Shift key to prevent accidental moves)
            f:SetScript("OnDragStart", function(self)
            if IsShiftKeyDown() then
                self:StartMoving()
                end
                end)
            f:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
            -- Save position to DB
            local point, _, relativePoint, x, y = self:GetPoint()
            MageReagentsPos = { point, relativePoint, x, y }
            end)

            if ldb and dataObj then
                dataObj.OnTooltipShow = function(tooltip) ShowTooltip(tooltip) end
                end

                -- 6. UPDATE LOGIC
                local function UpdateReagentCounts()
                local textParts = {}

                for _, id in ipairs(displayOrder) do
                    local count = GetItemCount(id, false, false)
                    local abbr = reagents[id].abbr

                    -- Color Logic
                    local colorCode = "ffffff"
                    if count < 5 then colorCode = "ff0000" end -- Red if low

                        table.insert(textParts, string.format("|cff%s%s: %d|r", colorCode, abbr, count))
                        end

                        local finalString = table.concat(textParts, "  ")

                        -- Update Standalone Window
                        f.text:SetText(finalString)
                        f:SetWidth(f.text:GetStringWidth() + 20) -- Auto-resize window width

                        -- Update Broker (Titan Panel)
                        if dataObj then
                            dataObj.text = finalString
                            end
                            end

                            -- 7. EVENTS & SAVED VARIABLES
                            f:RegisterEvent("PLAYER_LOGIN")
                            f:RegisterEvent("BAG_UPDATE")

                            f:SetScript("OnEvent", function(self, event, ...)
                            if event == "PLAYER_LOGIN" then
                                -- Restore position
                                if MageReagentsPos then
                                    self:ClearAllPoints()
                                    self:SetPoint(MageReagentsPos[1], UIParent, MageReagentsPos[2], MageReagentsPos[3], MageReagentsPos[4])
                                    end
                                    UpdateReagentCounts()
                                    elseif event == "BAG_UPDATE" then
                                        UpdateReagentCounts()
                                        end
                                        end)
